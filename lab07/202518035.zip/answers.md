# Lab 19–22a — Answers

Copy this file into your Codespace, rename it `answers.md`, and fill in your roll number and name.
Write **3–6 sentences** under each question, in place of *(your answer here)*. Leave the `##` headings
and the `>` question lines as they are: the marking script reads your answers by heading.

Each answer is marked on two things: naming the **mechanism** (saturation, rounding bias, range against
step, the zero-point), and pointing to **your code** (a TODO, a line) or to **a number you printed**.
Questions are worth 40 marks in total; the heaviest are **Q2** and **Q6**.

**Roll**: 202518035
**Name**: Aditya Jana

---

## Q1 — Saturation (5 marks)

> In `fixed_point.py`, `FixedPoint(7.0) + FixedPoint(7.0)` prints `7.9375`. Which TODO produces that
> number, and what raw values go in and come out? What would a plain int8 addition return instead,
> and why is saturating the safer failure for a model's activations?

The saturation mechanism in TODO C of fixed_point.py produces 7.9375. Each FixedPoint(7.0) has a raw value of 112 because the scale is 16, so their addition produces a raw value of 224. TODO: C clamps this value to the maximum allowed raw integer, 127, which represents 127/16 = 7.9375. A plain signed int8 addition would wrap 224 to -32 in two's-complement arithmetic, representing -2.0. Saturation is safer for model activations because it limits the error rather than unexpectedly changing a large positive value to a negative one, which destabilises neural network layers (e.g., causing them to be zeroed out completely by a subsequent ReLU).

## Q2 — Rounding bias (8 marks)

> `FixedPoint(0.0625) * FixedPoint(0.5)` gives raw 1, but `FixedPoint(-0.0625) * FixedPoint(0.5)` gives
> raw 0. Trace both through TODOs D–F: the wide product, the bias, the shift. Why are the ties
> asymmetric, and what does that do to the error across a million-term dot product
> (Lecture 19/20 §4)?

In Q3.4, the scale is 16, and the rounding bias is (2^{4-1}=8). For positive multiplication, the wide product is (1×8=8), so adding the bias(=8) gives 16, and shifting right by 4 produces a raw value of 1. For negative multiplication, the wide product is (-1 × 8 =-8), so adding the same bias gives 0, and shifting right by 4 produces a raw value of 0. Both exact results are halfway between representable values, but the positive bias makes both ties round toward positive infinity rather than symmetrically around zero. Each of these examples introduces a positive error of 0.03125, so repeated ties can accumulate a substantial positive error in a million-term dot product instead of cancelling out.

## Q3 — Range against step (5 marks)

> Q1.6 and Q3.4 are both 8 bits. Give the step and the range of each, computed with your TODO A and
> TODO B. Which would you pick for weights in [-1, 1], and what do you give up?

Both formats use 8 bits in total, including 1 sign bit. For Q1.6, there is 1 integer bit and 6 fractional bits. Therefore, the step size is (2^{-6}=1/64=0.015625). The range is calculated as ([-2^1,\ 2^1-0.015625]), which gives ([-2,\ 1.984375]).

For Q3.4, there are 3 integer bits and 4 fractional bits. Its step size is (2^{-4}=1/16=0.0625), and its range is ([-2^3,\ 2^3-0.0625]=[-8,\ 7.9375]). I would choose Q1.6 for weights in ([-1,1]) because both endpoints fit within its range, and its smaller step provides finer precision. However, this comes at the cost of a smaller representable range and less headroom for larger values.

## Q4 — Ties up against ties to even (5 marks)

> `FixedPoint` rounds ties **up**; `np.round` in your TODO E rounds them **to even**. Quantize
> `0.03125` and `0.09375` with a signed int8 `AffineQuantizer` calibrated on `[-8.0, 7.9375]` and
> report the integers. Which rule had the smaller error in Lecture 19/20 §4, and why do two
> frameworks that differ only here drift apart on the same model?

From the lecture, the affine quantization formula is:

Scale:
S = (r_max - r_min) / (q_max - q_min)

Zero-point:
Z = round(q_min - r_min / S)

Quantization:
q = clip(round(r / S + Z), q_min, q_max)

For signed int8, the integer range is [-128, 127] and the calibrated real range is [-8.0, 7.9375].

The scale is:

S = (7.9375 - (-8)) / (127 - (-128))

S = 15.9375 / 255 = 0.0625

The zero-point is:

Z = round(-128 - (-8 / 0.0625)) = 0

Using q = round(r / S + Z):

For 0.03125:

q = round(0.03125 / 0.0625) = round(0.5) = 0

For 0.09375:

q = round(0.09375 / 0.0625) = round(1.5) = 2

Therefore, the quantised integers are [0, 2].

In round-half-to-even, ties are rounded to the nearest even integer. This is why 0.5 becomes 0 and 1.5 becomes 2. According to Lecture 19/20 §4, round-half-to-even had a smaller accumulated error (-2.84) than round-half-up (+38.22), because it reduces the directional bias caused by always rounding ties upwards. Different rounding rules can produce different integer values for the same inputs, and these differences can accumulate through model operations, causing outputs to drift apart.



## Q5 — Stretching the range to include zero (5 marks)

> Calibrate an unsigned 8-bit quantizer on `[2.0, 5.0]`. Report the scale and zero-point it chooses.
> How many of the 256 integers sit below real 2.0 and are never used? What would break if TODO B
> were skipped?



From the lecture, TODO B first adjusts the calibration range to include zero:

r_min = min(0, r_min)

r_max = max(0, r_max)

For the given range [2.0, 5.0], the adjusted range becomes [0.0, 5.0].

For an unsigned 8-bit quantizer, q_min = 0 and q_max = 255.

Using the scale formula:

S = (r_max - r_min) / (q_max - q_min)

S = (5 - 0) / (255 - 0) = 5/255 ≈ 0.019608

Using the zero-point formula:

Z = round(q_min - r_min / S)

Z = round(0 - 0/0.019608) = 0

The real value 2.0 maps to:

q = round(2.0 / 0.019608) = 102

Therefore, the integers 0 to 101 are never used, so **102 of the 256 integers** lie below the calibrated real value 2.0.

If TODO B were skipped, the zero-point would be:

Z = round(0 - 2/(3/255)) = -170

This is outside the valid unsigned integer range [0, 255]. Therefore, zero could not be represented exactly. This would cause problems in operations such as zero-padding, where the quantizer must represent real zero correctly.



## Q6 — Why zero must be exact (8 marks)

> A ReLU output is exactly 0.0, and a convolution pads its input with the integer `Z`. Why must
> `dequantize(Z)` be exactly 0.0, not 0.004? Point to the lines in TODO B and TODO D that guarantee
> it, and say what error a padded border would pick up if they did not (Lecture 21/22 §2).



The lecture gives the dequantization formula:

real = S × (q - Z)

For q = Z:

dequantize(Z) = S × (Z - Z) = 0.0

This is important because ReLU produces exact zero, and convolution uses the integer Z to represent zero while padding the input.

In TODO B, these two lines stretch the calibration range to include zero:

r_min = min(0, r_min)

r_max = max(0, r_max)

This ensures that zero lies within the calibrated range.

In TODO D, the zero-point is calculated using:

self.zero_point = int(round(self.q_min - r_min / self.scale))

This gives an integer representation of real zero. Therefore, when we dequantize that integer Z, the result is exactly zero.

If zero were represented as 0.004, the padding added during convolution would contain 0.004 instead of zero. These nonzero values would be multiplied by the filter weights and added to the convolution result, introducing unwanted errors near the input boundaries. Therefore, zero must be represented exactly.





## Q7 — The four-term dot product (4 marks)

> Expand `sum((q_w - z_w) * (q_x - z_x))` into the four terms of TODO G. Which can be computed once
> from the weights, and which must be recomputed for every input? Set `z_w = 0`: which two terms
> vanish, and why is that the reason weights are usually quantized symmetrically (Lecture 21/22 §4)?
> Answer from the algebra even if you did not attempt TODO G.



Starting with the expression:

sum((q_w - z_w) * (q_x - z_x))

Expanding it gives:

sum(q_w * q_x) - z_x * sum(q_w) - z_w * sum(q_x) + n * z_w * z_x

These are the four terms used in TODO G.

The sum of quantised weights, sum(q_w), can be calculated once per weight row, since the weights remain fixed. However, the sum of quantised inputs, sum(q_x), must be recalculated for every new input. The main dot product also needs to be calculated for every input. The last term is constant when the dimensions and zero-points remain fixed, so it can be calculated once.

When z_w = 0, the third term and the fourth term become zero. This simplifies the calculation because we no longer need the input-sum correction or the constant offset. This is why weights are usually quantised symmetrically, with a zero-point of zero: it reduces the computation required during inference.

